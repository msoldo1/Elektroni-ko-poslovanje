﻿namespace EP.Marin_Valentina.Models.Vacation
{
    public class ExtendedGo : VacationFields
    {
        public string Etag { get; set; }
    }
}