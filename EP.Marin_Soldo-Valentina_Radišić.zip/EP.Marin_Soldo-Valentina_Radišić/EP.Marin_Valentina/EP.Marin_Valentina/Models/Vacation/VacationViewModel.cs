﻿namespace EP.Marin_Valentina.Models.Vacation
{
    public class VacationViewModel
    {
        public string ObjectType { get; set; }

        public string Id { get; set; }

        public VacationFields Fields { get; set; }

        public Links Links { get; set; }
    }
}
