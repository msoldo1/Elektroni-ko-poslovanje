﻿namespace EP.Marin_Valentina.Models.Vacation
{
    public class Links
    {
        public string Self { get; set; }

        public string Dossier { get; set; }
    }
}