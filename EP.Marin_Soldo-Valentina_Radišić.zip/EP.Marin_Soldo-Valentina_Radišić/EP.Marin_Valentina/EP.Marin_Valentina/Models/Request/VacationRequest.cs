﻿using System;
using EP.Marin_Valentina.Converters;
using Newtonsoft.Json;

namespace EP.Marin_Valentina.Models.Request
{
    public class VacationRequest
    {
        [JsonConverter(typeof(GenesisDateConverter))]
        public DateTime START_DT { get; set; }

        [JsonConverter(typeof(GenesisDateConverter))]
        public DateTime END_DT { get; set; }

        public string KEYWORD { get; set; }

        public bool GWDURATIONMANUAL { get; set; }

    }
}