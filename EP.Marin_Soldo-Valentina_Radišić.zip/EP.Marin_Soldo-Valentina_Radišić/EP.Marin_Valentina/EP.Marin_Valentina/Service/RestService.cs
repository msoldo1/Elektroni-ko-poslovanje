﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Cache;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using EP.Marin_Valentina.Models.Request;
using EP.Marin_Valentina.Models.Vacation;
using EP.Marin_Valentina.Settings;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using RestSharp;

namespace EP.Marin_Valentina.Service
{
    public class RestService : IRestService
    {
        private readonly IMapper _mapper;
        private readonly HttpSettings _settings;


        public RestService(IOptions<HttpSettings> settings, IMapper mapper)
        {
            _mapper = mapper;
            _settings = settings.Value;
        }

        public async Task<List<VacationViewModel>> GetVacationsAsync()
        {
            var client = GetGenesisClient();

            var cancellationTokenSource = new CancellationTokenSource();

            var request = new RestRequest("/v3.0/type/APPOINTMENT/list", Method.GET, DataFormat.Json);

            var restResponse = await client.ExecuteAsync(request, cancellationTokenSource.Token);

            var response = JsonConvert.DeserializeObject<List<VacationViewModel>>(restResponse.Content);

            return response;
        }

        public async Task<ExtendedGo> GetVacationAsync(string id)
        {
            var client = GetGenesisClient();

            var cancellationTokenSource = new CancellationTokenSource();

            var request = new RestRequest($"/v3.0/type/APPOINTMENT/{id}", Method.GET, DataFormat.Json);

            var restResponse = await client.ExecuteAsync(request, cancellationTokenSource.Token);

            var response = JsonConvert.DeserializeObject<VacationViewModel>(restResponse.Content);

            var result = _mapper.Map<VacationFields, ExtendedGo>(response.Fields);

            result.Etag = restResponse.Headers.FirstOrDefault(x => x.Name.ToUpperInvariant() == "ETAG")?.Value.ToString();

            return result;
        }

        public async Task UpdateVacationAsync(ExtendedGo model)
        {
            var client = GetGenesisClient();

            var cancellationTokenSource = new CancellationTokenSource();

            var request = new RestRequest($"/v3.0/type/APPOINTMENT/{model.GGUID}", Method.PUT, DataFormat.Json);

            request.AddHeader("If-Match", model.Etag);

            var body = _mapper.Map<ExtendedGo, VacationRequest>(model);

            var data = new {fields = body};

            var serialized = JsonConvert.SerializeObject(data);

            request.AddJsonBody(serialized);

            await client.ExecuteAsync(request, cancellationTokenSource.Token);
        }

        public async Task CreateVacationAsync(VacationFields model)
        {
            var client = GetGenesisClient();

            var cancellationTokenSource = new CancellationTokenSource();

            var request = new RestRequest("/v3.0/type/APPOINTMENT", Method.POST, DataFormat.Json);

            var body = _mapper.Map<VacationFields, VacationRequest>(model);

            var data = new {fields = body};

            var serialized = JsonConvert.SerializeObject(data);

            request.AddJsonBody(serialized);

            await client.ExecuteAsync(request, cancellationTokenSource.Token);
        }

        public async Task DeleteVacationAsync(string id)
        {
            var client = GetGenesisClient();

            var cancellationTokenSource = new CancellationTokenSource();

            var request = new RestRequest($"/v3.0/type/APPOINTMENT/{id}", Method.DELETE, DataFormat.Json);

            await client.ExecuteAsync(request, cancellationTokenSource.Token);
        }

        private RestClient GetGenesisClient()
        {
            var encoding = new UTF8Encoding();

            var client = new RestClient(_settings.Url) {CachePolicy = new RequestCachePolicy(RequestCacheLevel.Default)};


            var authInfo = Convert.ToBase64String(encoding.GetBytes(_settings.Username + ":" + _settings.Password));

            client.AddDefaultHeader("Authorization", $"Basic {authInfo}");
            client.AddDefaultHeader("X-CAS-PRODUCT-KEY", _settings.ProductKey);
            client.Timeout = 15000;

            return client;
        }
    }
}