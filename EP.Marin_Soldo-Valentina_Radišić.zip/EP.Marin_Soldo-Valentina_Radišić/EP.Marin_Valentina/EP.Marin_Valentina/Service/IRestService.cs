﻿using System.Collections.Generic;
using System.Threading.Tasks;
using EP.Marin_Valentina.Models.Vacation;

namespace EP.Marin_Valentina.Service
{
    public interface IRestService
    {
        Task<List<VacationViewModel>> GetVacationsAsync();

        Task<ExtendedGo> GetVacationAsync(string id);

        Task UpdateVacationAsync(ExtendedGo model);

        Task CreateVacationAsync(VacationFields model);

        Task DeleteVacationAsync(string id);
    }
}