﻿using System;
using AutoMapper;
using EP.Marin_Valentina.Database;
using EP.Marin_Valentina.Service;
using EP.Marin_Valentina.Settings;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace EP.Marin_Valentina
{
    public class Startup
    {
        private readonly IConfigurationSection _httpSettingsSection;


        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
            _httpSettingsSection = configuration.GetSection(nameof(HttpSettings));
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<HttpSettings>(_httpSettingsSection);

            services.AddTransient<IRestService, RestService>();

            services.AddDbContext<VacationDbContext>(options => options.UseInMemoryDatabase("VacationsDb"));


            services.Configure<CookiePolicyOptions>(options =>
            {
                options.CheckConsentNeeded = context => true;
                options.MinimumSameSitePolicy = SameSiteMode.None;
            });


            services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());


            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseCookiePolicy();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    "default",
                    "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}