﻿using AutoMapper;
using EP.Marin_Valentina.Models.Request;
using EP.Marin_Valentina.Models.Vacation;

namespace EP.Marin_Valentina.Mappings
{
    public class VacationProfile : Profile
    {
        public VacationProfile()
        {
            CreateMap<VacationFields, VacationRequest>().ReverseMap();

            CreateMap<VacationFields, ExtendedGo>().ReverseMap();
        }
    }
}