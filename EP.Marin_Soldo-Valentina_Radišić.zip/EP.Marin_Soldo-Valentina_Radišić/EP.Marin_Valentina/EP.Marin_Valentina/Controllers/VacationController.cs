﻿using System;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using EP.Marin_Valentina.Models.Vacation;
using EP.Marin_Valentina.Service;
using Microsoft.AspNetCore.Mvc;

namespace EP.Marin_Valentina.Controllers
{
    public class VacationController : Controller
    {
        private readonly IMapper _mapper;
        private readonly IRestService _service;
        private static string ETAG = "";

        public VacationController(IRestService service, IMapper mapper)
        {
            _service = service;
            _mapper = mapper;
        }

        // GET: Vacation
        public async Task<IActionResult> Index()
        {
            var response = await _service.GetVacationsAsync();

            return View(response.Select(x => x.Fields));
        }

        // GET: Vacation/Details/5
        public async Task<IActionResult> Details(string id)
        {
            if (id == null) return NotFound();

            var response = await _service.GetVacationAsync(id);

            if (response == null) return NotFound();

            return View(response);
        }

        // GET: Vacation/Create
        public IActionResult Create()
        {
            var model = new VacationFields {START_DT = DateTime.Now, END_DT = DateTime.Now.AddDays(1)};


            return View(model);
        }

        // POST: Vacation/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("END_DT,GWDURATIONMANUAL,START_DT,KEYWORD")] VacationFields vacationFields)
        {
            if (ModelState.IsValid)
            {
                await _service.CreateVacationAsync(vacationFields);
                return RedirectToAction(nameof(Index));
            }

            return View(vacationFields);
        }

        // GET: Vacation/Edit/5
        public async Task<IActionResult> Edit(string id)
        {
            if (id == null) return NotFound();

            var response = await _service.GetVacationAsync(id);

           ETAG = response.Etag;

            return View(response);
        }

        // POST: Vacation/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, [Bind("GGUID,END_DT,GWDURATIONMANUAL,START_DT,KEYWORD")]VacationFields vacationFields)
        {
            if (ModelState.IsValid)
            {
                vacationFields.GGUID = id;
                var model = _mapper.Map<VacationFields, ExtendedGo>(vacationFields);
                model.Etag = ETAG;

                await _service.UpdateVacationAsync(model);

                return RedirectToAction(nameof(Index));
            }

            return View(vacationFields);
        }

        // GET: Vacation/Delete/5
        public async Task<IActionResult> Delete(string id)
        {
            if (id == null) return NotFound();

            var response = await _service.GetVacationAsync(id);

            if (response == null) return NotFound();

            return View(response);
        }

        // POST: Vacation/Delete/5
        [HttpPost]
        [ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            await _service.DeleteVacationAsync(id);

            return RedirectToAction(nameof(Index));
        }
    }
}