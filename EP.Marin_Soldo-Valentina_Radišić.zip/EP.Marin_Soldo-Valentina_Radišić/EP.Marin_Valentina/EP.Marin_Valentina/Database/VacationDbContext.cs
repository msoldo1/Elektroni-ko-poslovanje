﻿using EP.Marin_Valentina.Models.Vacation;
using Microsoft.EntityFrameworkCore;

namespace EP.Marin_Valentina.Database
{
    public class VacationDbContext : DbContext
    {
        public VacationDbContext(DbContextOptions<VacationDbContext> options) : base(options)
        {
        }

        public DbSet<VacationFields> Vacations { get; set; }

    }
}
